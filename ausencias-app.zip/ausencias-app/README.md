# Control de Ausencias 2026
Dashboard web conectado en tiempo real con Smartsheet.

---

## Estructura del proyecto

```
ausencias-app/
├── server.js          ← Backend (Node.js + Express)
├── package.json
└── public/
    ├── index.html     ← Frontend
    └── app.js         ← Lógica del dashboard
```

---

## Requisitos

- Node.js 18 o superior
- Token de API de Smartsheet (con acceso al sheet de archivo)

---

## Cómo obtener tu token de Smartsheet

1. Entra a **Smartsheet**
2. Ve a tu avatar → **Cuenta** → **Configuración personal**
3. En la sección **API Access**, haz clic en **Generar nuevo token de acceso personal**
4. Copia el token — solo se muestra una vez

---

## Instalación local

```bash
# 1. Entra a la carpeta
cd ausencias-app

# 2. Instala dependencias
npm install

# 3. Inicia el servidor
npm start

# 4. Abre en el navegador
# http://localhost:3000
```

Al abrir la app, ingresa tu token de Smartsheet en la pantalla de inicio.

---

## Despliegue en producción

### Opción A — Railway (recomendado, gratis para empezar)

1. Crea cuenta en [railway.app](https://railway.app)
2. Nuevo proyecto → **Deploy from GitHub** (sube el código a un repo)
3. En Variables de entorno agrega:
   ```
   SMARTSHEET_TOKEN = tu_token_aqui
   PORT = 3000
   ```
4. Railway genera una URL pública automáticamente

### Opción B — Render

1. Crea cuenta en [render.com](https://render.com)
2. Nuevo **Web Service** → conecta tu repo de GitHub
3. Build command: `npm install`
4. Start command: `npm start`
5. Agrega variable de entorno: `SMARTSHEET_TOKEN`

### Opción C — Servidor propio (VPS/Linux)

```bash
# Instalar Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs

# Clonar/subir el proyecto y entrar a la carpeta
cd ausencias-app
npm install

# Ejecutar con PM2 para que corra en segundo plano
npm install -g pm2
SMARTSHEET_TOKEN="tu_token_aqui" pm2 start server.js --name ausencias
pm2 save
pm2 startup
```

---

## Columnas de Smartsheet que usa el dashboard

| Campo            | Columna en Smartsheet        | ID de columna        |
|------------------|------------------------------|----------------------|
| Empleado         | Nombre Empleado              | 4843925872004996     |
| Supervisor       | Supervisor                   | 2592126058319748     |
| Departamento     | Departamento                 | 1466226151477124     |
| Tipo             | Tipo Ausencia                | 2964364162977668     |
| Fecha            | Fecha de Inicio              | 8801566101032836     |
| Status HR        | Status HR                    | 8593863697190788     |
| Comentarios      | Comentarios                  | 6683470817087364     |
| Justificación    | Justificación                | 216579311357828      |

Sheet ID: `7423562282389380`

---

## Funcionalidades

- Carga todos los registros del Smartsheet de archivo en tiempo real
- Filtros por tipo, departamento, mes y Status HR
- Editar **Status HR** directamente desde el dashboard (se guarda en Smartsheet al cambiar)
- Añadir/editar **Comentarios** por registro (se guardan en Smartsheet)
- Vista **Por Empleado** cruzada con roster — identifica empleados sin reporte
- Resumen visual con gráficas de barras
- Botón de sincronización manual

---

## Seguridad

- El token de Smartsheet se puede configurar como variable de entorno en el servidor (`SMARTSHEET_TOKEN`) para que los usuarios no necesiten ingresarlo
- Si se deja la pantalla de login, el token se guarda en `localStorage` del navegador del usuario y se envía al backend en cada request vía header `x-ss-token`
- Nunca se almacena en base de datos ni se registra en logs
